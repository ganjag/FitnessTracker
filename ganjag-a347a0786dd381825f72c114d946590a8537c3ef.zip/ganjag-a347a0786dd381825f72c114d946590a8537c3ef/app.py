from flask import Flask, flash, redirect, render_template, request, session, jsonify, url_for
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
import cs50
import matplotlib.pyplot as plt
import io
import base64
from helpers import apology, login_required

# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = cs50.SQL("sqlite:///fitness.db")

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/")
@login_required
def index():
    exercises = db.execute("SELECT DISTINCT exercise FROM history WHERE user_id = ?", session["user_id"])
    if not exercises:
        exercises = []
    return render_template("index.html", exercises=exercises)

@app.route("/enter", methods=["GET", "POST"])
@login_required
def enter():
    if request.method == "POST":
        exercise = request.form.get("exercise")
        repetitions = request.form.get("repetitions")
        weight = request.form.get("weight")
        comments = request.form.get("comments")
        date = request.form.get("date")

        if not exercise or not repetitions or not weight or not date:
            return apology("Missing required field(s)")

        db.execute("INSERT INTO history (user_id, exercise, repetitions, weight, comments, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
                   session["user_id"], exercise, repetitions, weight, comments, date)

        flash("Exercise logged!")
        return redirect("/enter")

    history = db.execute("SELECT id, exercise, repetitions, weight, comments, timestamp FROM history WHERE user_id = ? ORDER BY timestamp DESC", session["user_id"])

    return render_template("enter.html", history=history)

@app.route("/update_entry", methods=["POST"])
@login_required
def update_entry():
    entry_id = request.form.get("id")
    weight = request.form.get("weight")
    comments = request.form.get("comments")
    date = request.form.get("date")

    if not entry_id or not weight or not date:
        return apology("Missing required field(s)")

    db.execute("UPDATE history SET weight = ?, comments = ?, timestamp = ? WHERE id = ? AND user_id = ?",
               weight, comments, date, entry_id, session["user_id"])

    flash("Entry updated!")
    return redirect("/enter")

@app.route("/delete_entry", methods=["POST"])
@login_required
def delete_entry():
    entry_id = request.form.get("id")

    if not entry_id:
        return apology("Missing required field(s)")

    db.execute("DELETE FROM history WHERE id = ? AND user_id = ?", entry_id, session["user_id"])

    flash("Entry deleted!")
    return redirect("/enter")

@app.route("/history", methods=["GET", "POST"])
@login_required
def history():
    if request.method == "POST":
        exercise = request.form.get("exercise")
        weight = request.form.get("weight")

        query = "SELECT * FROM history WHERE user_id = ?"
        params = [session["user_id"]]

        if exercise:
            query += " AND exercise = ?"
            params.append(exercise)
        if weight:
            query += " AND weight = ?"
            params.append(weight)

        query += " ORDER BY timestamp DESC"
        rows = db.execute(query, *params)
    else:
        rows = db.execute("SELECT * FROM history WHERE user_id = ? ORDER BY timestamp DESC", session["user_id"])

    return render_template("history.html", rows=rows)

@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()

    if request.method == "POST":
        if not request.form.get("username"):
            return apology("must provide username", 403)

        if not request.form.get("password"):
            return apology("must provide password", 403)

        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        session["user_id"] = rows[0]["id"]
        return redirect(url_for("index"))

    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect("/login")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    elif request.method == "POST":
        username = request.form.get("username")
        if not username:
            return apology("Please enter a user name.")

        password = request.form.get("password")
        if not password:
            return apology("Please enter a password.")

        confirmation = request.form.get("confirmation")
        if not confirmation:
            return apology("Please repeat the password.")
        elif password != confirmation:
            return apology("Passwords don't match")

        hash = generate_password_hash(password, method='pbkdf2', salt_length=16)

        try:
            db.execute("INSERT INTO users (username, hash) VALUES(?, ?)", username, hash)
        except ValueError:
            return apology("User name is already taken.")

        flash("Registered successfully! Please log in.", "success")
    return redirect("/login")

@app.route("/exercise_data")
@login_required
def exercise_data():
    exercise = request.args.get("exercise")
    data = db.execute("SELECT timestamp, weight FROM history WHERE user_id = ? AND exercise = ? ORDER BY timestamp", session["user_id"], exercise)
    return jsonify(data)

@app.route("/graph_data")
@login_required
def graph_data():
    exercise_filter = request.args.get("exercise")
    query = "SELECT exercise, MAX(weight) as weight, DATE(timestamp) as date FROM history WHERE user_id = ?"
    params = [session["user_id"]]

    if exercise_filter:
        query += " AND exercise = ?"
        params.append(exercise_filter)

    query += " GROUP BY exercise, DATE(timestamp)"
    data = db.execute(query, *params)

    # Prepare the data for the chart
    chart_data = {"labels": [], "datasets": []}
    exercises = {}

    for row in data:
        if row["exercise"] not in exercises:
            exercises[row["exercise"]] = {"label": row["exercise"], "data": [], "borderColor": "", "fill": False}

        exercises[row["exercise"]]["data"].append({"x": row["date"], "y": row["weight"]})

    # Assign colors
    colors = ["#ff99cc", "#ff66b2", "#ff3399", "#ff1a75", "#e6005c", "#b30047"]
    for i, (exercise, dataset) in enumerate(exercises.items()):
        dataset["borderColor"] = colors[i % len(colors)]
        chart_data["datasets"].append(dataset)

    chart_data["labels"] = sorted(list(set(row["date"] for row in data)))

    return jsonify(chart_data)

@app.route("/community", methods=["GET", "POST"])
@login_required
def community():
    if request.method == "POST":
        content = request.form.get("post")
        if not content:
            return apology("Cannot post empty content.")
        db.execute("INSERT INTO posts (user_id, content, timestamp) VALUES (?, ?, ?)",
                   session["user_id"], content, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        flash("Post submitted!")
        return redirect("/community")

    posts = db.execute("SELECT posts.id, posts.content, posts.timestamp, users.username, (SELECT COUNT(*) FROM post_likes WHERE post_likes.post_id = posts.id) as like_count FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.timestamp DESC")

    for post in posts:
        post["comments"] = db.execute("SELECT comments.id, comments.content, comments.timestamp, users.username, (SELECT COUNT(*) FROM comment_likes WHERE comment_likes.comment_id = comments.id) as like_count FROM comments JOIN users ON comments.user_id = users.id WHERE comments.post_id = ? ORDER BY comments.timestamp ASC", post["id"])

    return render_template("community.html", posts=posts)

@app.route("/like_post", methods=["POST"])
@login_required
def like_post():
    post_id = request.form.get("post_id")

    if not post_id:
        return apology("Missing post ID")

    existing_like = db.execute("SELECT * FROM post_likes WHERE user_id = ? AND post_id = ?", session["user_id"], post_id)
    if existing_like:
        db.execute("DELETE FROM post_likes WHERE user_id = ? AND post_id = ?", session["user_id"], post_id)
    else:
        db.execute("INSERT INTO post_likes (user_id, post_id) VALUES (?, ?)", session["user_id"], post_id)

    return redirect("/community")

@app.route("/like_comment", methods=["POST"])
@login_required
def like_comment():
    comment_id = request.form.get("comment_id")

    if not comment_id:
        return apology("Missing comment ID")

    existing_like = db.execute("SELECT * FROM comment_likes WHERE user_id = ? AND comment_id = ?", session["user_id"], comment_id)
    if existing_like:
        db.execute("DELETE FROM comment_likes WHERE user_id = ? AND comment_id = ?", session["user_id"], comment_id)
    else:
        db.execute("INSERT INTO comment_likes (user_id, comment_id) VALUES (?, ?)", session["user_id"], comment_id)

    return redirect("/community")

@app.route("/comment", methods=["POST"])
@login_required
def comment():
    post_id = request.form.get("post_id")
    content = request.form.get("comment")

    if not content:
        return apology("Cannot post empty comment.")

    db.execute("INSERT INTO comments (user_id, post_id, content, timestamp) VALUES (?, ?, ?, ?)",
               session["user_id"], post_id, content, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    flash("Comment submitted!")
    return redirect("/community")

if __name__ == "__main__":
    app.run(debug=True)
