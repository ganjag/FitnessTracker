from flask import redirect, render_template, request, session
from functools import wraps

def convert_weight(weight, from_unit, to_unit):
    if from_unit == to_unit:
        return weight
    elif from_unit == 'kg' and to_unit == 'lbs':
        return weight * 2.20462
    elif from_unit == 'lbs' and to_unit == 'kg':
        return weight / 2.20462
    else:
        raise ValueError("Invalid unit conversion")


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.

    https://flask.palletsprojects.com/en/latest/patterns/viewdecorators/
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function
